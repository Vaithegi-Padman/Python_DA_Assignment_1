import numpy as np

# Create a 1D NumPy array for Week 1 temperatures
temperatures_w1 = np.array([22.5, 25.3, 20.8, 23.4, 26.1, 24.8, 21.9])

# Display the array
print("Week 1 Temperatures:", temperatures_w1)
import numpy as np

temperatures_w1 = np.array([22.5, 25.3, 20.8, 23.4, 26.1, 24.8, 21.9])

# Inspect the shape of the array
print("Shape of the array:", temperatures_w1.shape)
import numpy as np

# Create a NumPy array for Week 1 temperatures in Celsius
temperatures_w1 = np.array([22.5, 25.3, 20.8, 23.4, 26.1, 24.8, 21.9])

# Convert Celsius to Fahrenheit
temperatures_f = (temperatures_w1 * 9/5) + 32
print("Temperatures in Fahrenheit:", temperatures_f)

# Find maximum temperature
print("Maximum temperature:", np.max(temperatures_w1), "°C")

# Find minimum temperature
print("Minimum temperature:", np.min(temperatures_w1), "°C")

# Find mean temperature
print("Mean temperature:", np.mean(temperatures_w1), "°C")
import numpy as np

# Create a NumPy array for Week 1 temperatures
temperatures_w1 = np.array([22.5, 25.3, 20.8, 23.4, 26.1, 24.8, 21.9])

# Extract temperatures for the first three days
print("First three days:", temperatures_w1[:3])

# Extract temperatures for the weekend (last two days)
print("Weekend temperatures:", temperatures_w1[-2:])

# Extract temperatures for the middle three days
print("Middle three days:", temperatures_w1[2:5])
import numpy as np

# Create a 2D NumPy array for two weeks
temperatures = np.array([
    [22.5, 25.3, 20.8, 23.4, 26.1, 24.8, 21.9],  # Week 1
    [19.2, 22.5, 21.3, 24.0, 23.5, 22.8, 20.1]   # Week 2
])

# Display the 2D array
print("Temperatures for two weeks:")
print(temperatures)

# Display the shape
print("Shape of the array:", temperatures.shape)
import numpy as np

# Create a 2D NumPy array for two weeks
temperatures = np.array([
    [22.5, 25.3, 20.8, 23.4, 26.1, 24.8, 21.9],
    [19.2, 22.5, 21.3, 24.0, 23.5, 22.8, 20.1]
])

# 1. Inspect array properties
print("Shape of the array:", temperatures.shape)
print("Data type of the array:", temperatures.dtype)
print("Total number of elements:", temperatures.size)

# 2. Extract temperatures for each week
print("\nWeek 1 temperatures:", temperatures[0])
print("Week 2 temperatures:", temperatures[1])

# 3. Extract weekend temperatures (last two days) for both weeks
print("Week 1 weekend temperatures:", temperatures[0, -2:])
print("Week 2 weekend temperatures:", temperatures[1, -2:])
import pandas as pd

# Create a Pandas Series with marks and custom indices
marks = pd.Series(
    [95, 92, 89, 85, 80],
    index=['Rank1', 'Rank2', 'Rank3', 'Rank4', 'Rank5']
)

# Display the Series
print("Student Marks:")
print(marks)
import pandas as pd

# Create a Pandas Series
marks = pd.Series(
    [95, 92, 89, 85, 80],
    index=['Rank1', 'Rank2', 'Rank3', 'Rank4', 'Rank5']
)

# 1. Access the 1st rank student's mark using integer position
print("Mark of 1st rank student:", marks.iloc[0])
import pandas as pd

# Create a Pandas Series
marks = pd.Series(
    [95, 92, 89, 85, 80],
    index=['Rank1', 'Rank2', 'Rank3', 'Rank4', 'Rank5']
)

# 1. Modify the mark of the 1st rank student to 100
marks.loc['Rank1'] = 100
print("After modifying Rank1:")
print(marks)

# 2. Remove the entry corresponding to the last rank
marks = marks.drop('Rank5')
print("\nAfter removing Rank5:")
print(marks)

# 3. Compute CGPA by dividing each mark by 10
cgpa = marks / 10
print("\nCGPA:")
print(cgpa)
import pandas as pd

# Create a Pandas DataFrame
transactions = pd.DataFrame({
    'TransactionID': [101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
    
    'ProductCategory': [
        'Electronics', 'Clothing', 'Electronics', 'Furniture',
        'Clothing', 'Electronics', 'Furniture', 'Clothing',
        'Furniture', 'Electronics'
    ],
    
    'Region': [
        'North', 'South', 'North', 'East', 'West',
        'North', 'East', 'West', 'South', 'North'
    ],
    
    'Amount': [200, 150, 300, 450, 200, 250, 300, 180, 350, 400]
})

# Display the DataFrame
print("Transaction Details:")
print(transactions)
import pandas as pd

# Create the DataFrame
transactions = pd.DataFrame({
    'TransactionID': [101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
    'ProductCategory': [
        'Electronics', 'Clothing', 'Electronics', 'Furniture',
        'Clothing', 'Electronics', 'Furniture', 'Clothing',
        'Furniture', 'Electronics'
    ],
    'Region': [
        'North', 'South', 'North', 'East', 'West',
        'North', 'East', 'West', 'South', 'North'
    ],
    'Amount': [200, 150, 300, 450, 200, 250, 300, 180, 350, 400]
})

# 1. Display the DataFrame
print("Complete Transactions DataFrame:")
print(transactions)

# Display the first 5 rows
print("\nFirst 5 rows:")
print(transactions.head())

# Display the last 5 rows
print("\nLast 5 rows:")
print(transactions.tail())

# Display basic information
print("\nShape:")
print(transactions.shape)

print("\nColumn names:")
print(transactions.columns)

print("\nData types:")
print(transactions.dtypes)

print("\nBasic information:")
transactions.info()

# 2. Display ProductCategory and Amount columns
print("\nProductCategory and Amount:")
print(transactions[['ProductCategory', 'Amount']])

# 3. Retrieve the last 3 columns using iloc
print("\nLast 3 columns:")
print(transactions.iloc[:, -3:])

# 4. Filter North region with Amount greater than 200
print("\nNorth region with Amount greater than 200:")
print(transactions[(transactions['Region'] == 'North') &
                   (transactions['Amount'] > 200)])

# 5. Value counts for ProductCategory
print("\nProduct category counts:")
print(transactions['ProductCategory'].value_counts())

# 6. Unique values in Region
print("\nUnique regions:")
print(transactions['Region'].unique())

# 7. Mean Amount for each Region
print("\nMean amount by region:")
print(transactions.groupby('Region')['Amount'].mean())
# Create the DataFrame
transactions = pd.DataFrame({
    'TransactionID': [101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
    'ProductCategory': [
        'Electronics', 'Clothing', 'Electronics', 'Furniture',
        'Clothing', 'Electronics', 'Furniture', 'Clothing',
        'Furniture', 'Electronics'
    ],
    'Region': [
        'North', 'South', 'North', 'East', 'West',
        'North', 'East', 'West', 'South', 'North'
    ],
    'Amount': [200, 150, 300, 450, 200, 250, 300, 180, 350, 400]
})

# 1. Modify Amount for TransactionID 102 to 165
transactions.loc[transactions['TransactionID'] == 102, 'Amount'] = 165
print("After modifying Amount:")
print(transactions)

# 2. Add a Discount column (10% of Amount)
transactions['Discount'] = transactions['Amount'] * 0.10
print("\nAfter adding Discount column:")
print(transactions)

# 3. Remove the row with TransactionID 109
transactions = transactions.drop(
    transactions[transactions['TransactionID'] == 109].index
)
print("\nAfter removing TransactionID 109:")
print(transactions)

# 4. Delete the Discount column
transactions = transactions.drop(columns=['Discount'])
print("\nAfter deleting Discount column:")
print(transactions)

